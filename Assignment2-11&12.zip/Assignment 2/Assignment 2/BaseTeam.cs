﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_2
{
    class BaseTeam
    {
        private string teamName;
        private string uniformType;
        private string jereseyNum;
        private string footWear;
        private string fieldType;
        public string sportDesc()
        {
            string showTeam = "Team Name: "+ teamName + "\n" + "Uniform: " + uniformType + "\n" + "Jersery Number: " + jereseyNum + "\n" + "Footwear: " + footWear + "\n" + "Playing Field: " + fieldType;
            return showTeam;
        }
        public string TeamName
        { 
            get
            {
                return teamName;
            }
            set
                {
                teamName = value;
            } 
        }
        public string UniformType
        {
            set
            { 
                uniformType = value;
            }
        }
        public string JerseyNum
        {
            set
            {
                jereseyNum = value;  
            }
        }
        public string FootWear
        {
            set
            {
                footWear = value;
            }
        }
        public string FieldType
        {
            set
            {
                fieldType = value;
            }
        }
    }
    
}
