﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
        class TennisTeam : BaseTeam
        {
            public string sportsGear;
            public string teamSize;
            public string refNum;

            public string TennisDesc()
            {
                string tenDesc = sportDesc() + "Sports Gear: " + sportsGear + "\n" + "Team Size: " + teamSize + "\n" + "Number of Refs: " + refNum;
                return tenDesc;
            }
        }
}
