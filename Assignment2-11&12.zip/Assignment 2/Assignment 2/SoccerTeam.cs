﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class SoccerTeam : BaseTeam
    {
        public string sportsGear;
        public string teamSize;
        public string refNum;

        public string SoccerDesc()
        {
            string socDesc = sportDesc() + "Sports Gear: " + sportsGear + "\n" + "Team Size: " + teamSize + "\n" + "Number of Refs: " + refNum;
            return socDesc;
        }
    }
}


