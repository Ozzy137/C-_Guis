﻿namespace Assignment_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBxUniform = new System.Windows.Forms.TextBox();
            this.txtBxJerNum = new System.Windows.Forms.TextBox();
            this.txtBxFoot = new System.Windows.Forms.TextBox();
            this.txtBxSportGr = new System.Windows.Forms.TextBox();
            this.txtBxFldTy = new System.Windows.Forms.TextBox();
            this.lblUni = new System.Windows.Forms.Label();
            this.lblSptGr = new System.Windows.Forms.Label();
            this.lbljers = new System.Windows.Forms.Label();
            this.lblftWr = new System.Windows.Forms.Label();
            this.lblBxField = new System.Windows.Forms.Label();
            this.txtBxRefNum = new System.Windows.Forms.TextBox();
            this.txtBxTmSz = new System.Windows.Forms.TextBox();
            this.lblRefNum = new System.Windows.Forms.Label();
            this.lblTmSz = new System.Windows.Forms.Label();
            this.rdBtnTennis = new System.Windows.Forms.RadioButton();
            this.rdBtnSoccer = new System.Windows.Forms.RadioButton();
            this.grpBxTeam = new System.Windows.Forms.GroupBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.lblTmNm = new System.Windows.Forms.Label();
            this.txtBoxName = new System.Windows.Forms.TextBox();
            this.btnFin = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.lblTmShw = new System.Windows.Forms.Label();
            this.grpBxTeam.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtBxUniform
            // 
            this.txtBxUniform.Location = new System.Drawing.Point(377, 158);
            this.txtBxUniform.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBxUniform.Name = "txtBxUniform";
            this.txtBxUniform.Size = new System.Drawing.Size(294, 27);
            this.txtBxUniform.TabIndex = 0;
            this.txtBxUniform.Text = "ex: Shirt, Shorts\"";
            this.txtBxUniform.Visible = false;
            // 
            // txtBxJerNum
            // 
            this.txtBxJerNum.Location = new System.Drawing.Point(377, 216);
            this.txtBxJerNum.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBxJerNum.Name = "txtBxJerNum";
            this.txtBxJerNum.Size = new System.Drawing.Size(140, 27);
            this.txtBxJerNum.TabIndex = 1;
            this.txtBxJerNum.Text = "ex: \"9\" or None";
            this.txtBxJerNum.Visible = false;
            // 
            // txtBxFoot
            // 
            this.txtBxFoot.Location = new System.Drawing.Point(377, 268);
            this.txtBxFoot.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBxFoot.Name = "txtBxFoot";
            this.txtBxFoot.Size = new System.Drawing.Size(294, 27);
            this.txtBxFoot.TabIndex = 2;
            this.txtBxFoot.Text = "ex: Football Cleats";
            this.txtBxFoot.Visible = false;
            // 
            // txtBxSportGr
            // 
            this.txtBxSportGr.Location = new System.Drawing.Point(377, 372);
            this.txtBxSportGr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBxSportGr.Name = "txtBxSportGr";
            this.txtBxSportGr.Size = new System.Drawing.Size(294, 27);
            this.txtBxSportGr.TabIndex = 3;
            this.txtBxSportGr.Text = "ex: Football Helmet, Knee Pads";
            this.txtBxSportGr.Visible = false;
            // 
            // txtBxFldTy
            // 
            this.txtBxFldTy.Location = new System.Drawing.Point(376, 318);
            this.txtBxFldTy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBxFldTy.Name = "txtBxFldTy";
            this.txtBxFldTy.Size = new System.Drawing.Size(294, 27);
            this.txtBxFldTy.TabIndex = 4;
            this.txtBxFldTy.Text = "ex: Football Field";
            this.txtBxFldTy.Visible = false;
            // 
            // lblUni
            // 
            this.lblUni.AutoSize = true;
            this.lblUni.Location = new System.Drawing.Point(288, 158);
            this.lblUni.Name = "lblUni";
            this.lblUni.Size = new System.Drawing.Size(78, 20);
            this.lblUni.TabIndex = 7;
            this.lblUni.Text = "Uniform: ";
            this.lblUni.Visible = false;
            // 
            // lblSptGr
            // 
            this.lblSptGr.AutoSize = true;
            this.lblSptGr.Location = new System.Drawing.Point(261, 372);
            this.lblSptGr.Name = "lblSptGr";
            this.lblSptGr.Size = new System.Drawing.Size(101, 20);
            this.lblSptGr.TabIndex = 8;
            this.lblSptGr.Text = "Sport Gear: ";
            this.lblSptGr.Visible = false;
            // 
            // lbljers
            // 
            this.lbljers.AutoSize = true;
            this.lbljers.Location = new System.Drawing.Point(222, 216);
            this.lbljers.Name = "lbljers";
            this.lbljers.Size = new System.Drawing.Size(139, 20);
            this.lbljers.TabIndex = 9;
            this.lbljers.Text = "Jersery Number: ";
            this.lbljers.Visible = false;
            // 
            // lblftWr
            // 
            this.lblftWr.AutoSize = true;
            this.lblftWr.Location = new System.Drawing.Point(267, 268);
            this.lblftWr.Name = "lblftWr";
            this.lblftWr.Size = new System.Drawing.Size(97, 20);
            this.lblftWr.TabIndex = 10;
            this.lblftWr.Text = "Foot Wear :";
            this.lblftWr.Visible = false;
            // 
            // lblBxField
            // 
            this.lblBxField.AutoSize = true;
            this.lblBxField.Location = new System.Drawing.Point(248, 321);
            this.lblBxField.Name = "lblBxField";
            this.lblBxField.Size = new System.Drawing.Size(114, 20);
            this.lblBxField.TabIndex = 11;
            this.lblBxField.Text = "Playing Field: ";
            this.lblBxField.Visible = false;
            // 
            // txtBxRefNum
            // 
            this.txtBxRefNum.Location = new System.Drawing.Point(377, 480);
            this.txtBxRefNum.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBxRefNum.Name = "txtBxRefNum";
            this.txtBxRefNum.Size = new System.Drawing.Size(140, 27);
            this.txtBxRefNum.TabIndex = 12;
            this.txtBxRefNum.Text = "ex: 3";
            this.txtBxRefNum.Visible = false;
            // 
            // txtBxTmSz
            // 
            this.txtBxTmSz.Location = new System.Drawing.Point(376, 426);
            this.txtBxTmSz.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBxTmSz.Name = "txtBxTmSz";
            this.txtBxTmSz.Size = new System.Drawing.Size(141, 27);
            this.txtBxTmSz.TabIndex = 13;
            this.txtBxTmSz.Text = "ex: 22";
            this.txtBxTmSz.Visible = false;
            // 
            // lblRefNum
            // 
            this.lblRefNum.AutoSize = true;
            this.lblRefNum.Location = new System.Drawing.Point(179, 484);
            this.lblRefNum.Name = "lblRefNum";
            this.lblRefNum.Size = new System.Drawing.Size(179, 20);
            this.lblRefNum.TabIndex = 16;
            this.lblRefNum.Text = "Number Of Referees:  ";
            this.lblRefNum.Visible = false;
            // 
            // lblTmSz
            // 
            this.lblTmSz.AutoSize = true;
            this.lblTmSz.Location = new System.Drawing.Point(261, 426);
            this.lblTmSz.Name = "lblTmSz";
            this.lblTmSz.Size = new System.Drawing.Size(99, 20);
            this.lblTmSz.TabIndex = 17;
            this.lblTmSz.Text = "Team Size: ";
            this.lblTmSz.Visible = false;
            // 
            // rdBtnTennis
            // 
            this.rdBtnTennis.AutoSize = true;
            this.rdBtnTennis.Location = new System.Drawing.Point(8, 38);
            this.rdBtnTennis.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rdBtnTennis.Name = "rdBtnTennis";
            this.rdBtnTennis.Size = new System.Drawing.Size(138, 24);
            this.rdBtnTennis.TabIndex = 18;
            this.rdBtnTennis.Text = "Tennis Team";
            this.rdBtnTennis.UseVisualStyleBackColor = true;
            // 
            // rdBtnSoccer
            // 
            this.rdBtnSoccer.AutoSize = true;
            this.rdBtnSoccer.Location = new System.Drawing.Point(8, 71);
            this.rdBtnSoccer.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rdBtnSoccer.Name = "rdBtnSoccer";
            this.rdBtnSoccer.Size = new System.Drawing.Size(141, 24);
            this.rdBtnSoccer.TabIndex = 19;
            this.rdBtnSoccer.Text = "Soccer Team";
            this.rdBtnSoccer.UseVisualStyleBackColor = true;
            // 
            // grpBxTeam
            // 
            this.grpBxTeam.Controls.Add(this.rdBtnTennis);
            this.grpBxTeam.Controls.Add(this.rdBtnSoccer);
            this.grpBxTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBxTeam.Location = new System.Drawing.Point(376, 13);
            this.grpBxTeam.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpBxTeam.Name = "grpBxTeam";
            this.grpBxTeam.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpBxTeam.Size = new System.Drawing.Size(250, 125);
            this.grpBxTeam.TabIndex = 20;
            this.grpBxTeam.TabStop = false;
            this.grpBxTeam.Text = "Select Your Team Sport";
            // 
            // btnCreate
            // 
            this.btnCreate.BackColor = System.Drawing.Color.Salmon;
            this.btnCreate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreate.ForeColor = System.Drawing.Color.Yellow;
            this.btnCreate.Location = new System.Drawing.Point(660, 62);
            this.btnCreate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(113, 62);
            this.btnCreate.TabIndex = 21;
            this.btnCreate.Text = "Create Team";
            this.btnCreate.UseVisualStyleBackColor = false;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // lblTmNm
            // 
            this.lblTmNm.AutoSize = true;
            this.lblTmNm.Location = new System.Drawing.Point(249, 181);
            this.lblTmNm.Name = "lblTmNm";
            this.lblTmNm.Size = new System.Drawing.Size(110, 20);
            this.lblTmNm.TabIndex = 23;
            this.lblTmNm.Text = "Team Name: ";
            // 
            // txtBoxName
            // 
            this.txtBoxName.Location = new System.Drawing.Point(377, 181);
            this.txtBoxName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBoxName.Name = "txtBoxName";
            this.txtBoxName.Size = new System.Drawing.Size(294, 27);
            this.txtBoxName.TabIndex = 22;
            this.txtBoxName.Text = "Name Here";
            // 
            // btnFin
            // 
            this.btnFin.BackColor = System.Drawing.Color.Salmon;
            this.btnFin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFin.ForeColor = System.Drawing.Color.Yellow;
            this.btnFin.Location = new System.Drawing.Point(675, 439);
            this.btnFin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnFin.Name = "btnFin";
            this.btnFin.Size = new System.Drawing.Size(124, 68);
            this.btnFin.TabIndex = 24;
            this.btnFin.Text = "Finish";
            this.btnFin.UseVisualStyleBackColor = false;
            this.btnFin.Visible = false;
            this.btnFin.Click += new System.EventHandler(this.btnFin_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Red;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.Gold;
            this.btnClear.Location = new System.Drawing.Point(553, 464);
            this.btnClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 41);
            this.btnClear.TabIndex = 25;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Visible = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.Red;
            this.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.Gold;
            this.btnReset.Location = new System.Drawing.Point(823, 466);
            this.btnReset.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(100, 41);
            this.btnReset.TabIndex = 26;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Visible = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lblTmShw
            // 
            this.lblTmShw.AutoSize = true;
            this.lblTmShw.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTmShw.Location = new System.Drawing.Point(371, 122);
            this.lblTmShw.Name = "lblTmShw";
            this.lblTmShw.Size = new System.Drawing.Size(262, 32);
            this.lblTmShw.TabIndex = 27;
            this.lblTmShw.Text = "Insert Team Name";
            this.lblTmShw.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkRed;
            this.ClientSize = new System.Drawing.Size(1000, 562);
            this.Controls.Add(this.lblTmShw);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnFin);
            this.Controls.Add(this.lblTmNm);
            this.Controls.Add(this.txtBoxName);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.grpBxTeam);
            this.Controls.Add(this.lblTmSz);
            this.Controls.Add(this.lblRefNum);
            this.Controls.Add(this.txtBxTmSz);
            this.Controls.Add(this.txtBxRefNum);
            this.Controls.Add(this.lblBxField);
            this.Controls.Add(this.lblftWr);
            this.Controls.Add(this.lbljers);
            this.Controls.Add(this.lblSptGr);
            this.Controls.Add(this.lblUni);
            this.Controls.Add(this.txtBxFldTy);
            this.Controls.Add(this.txtBxSportGr);
            this.Controls.Add(this.txtBxFoot);
            this.Controls.Add(this.txtBxJerNum);
            this.Controls.Add(this.txtBxUniform);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Khaki;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Sports APP";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpBxTeam.ResumeLayout(false);
            this.grpBxTeam.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBxUniform;
        private System.Windows.Forms.TextBox txtBxJerNum;
        private System.Windows.Forms.TextBox txtBxFoot;
        private System.Windows.Forms.TextBox txtBxSportGr;
        private System.Windows.Forms.TextBox txtBxFldTy;
        private System.Windows.Forms.Label lblUni;
        private System.Windows.Forms.Label lblSptGr;
        private System.Windows.Forms.Label lbljers;
        private System.Windows.Forms.Label lblftWr;
        private System.Windows.Forms.Label lblBxField;
        private System.Windows.Forms.TextBox txtBxRefNum;
        private System.Windows.Forms.TextBox txtBxTmSz;
        private System.Windows.Forms.Label lblRefNum;
        private System.Windows.Forms.Label lblTmSz;
        private System.Windows.Forms.RadioButton rdBtnTennis;
        private System.Windows.Forms.RadioButton rdBtnSoccer;
        private System.Windows.Forms.GroupBox grpBxTeam;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Label lblTmNm;
        private System.Windows.Forms.TextBox txtBoxName;
        private System.Windows.Forms.Button btnFin;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblTmShw;
        private System.Windows.Forms.Button btnReset;
    }
}

