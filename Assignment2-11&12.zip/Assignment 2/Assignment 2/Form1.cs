﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }
        public string radioBtnCheck()
        {
            string sportName = " ";

            if (rdBtnSoccer.Checked == true)
            {
                sportName = txtBoxName.Text;
            }

            else if(rdBtnTennis.Checked == true)
            {
                sportName = txtBoxName.Text;
            }
            return sportName;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            lblTmShw.Text = "Team Name: " + radioBtnCheck();

            if (rdBtnSoccer.Checked == false && rdBtnTennis.Checked == false)
            { 
                MessageBox.Show("Please Pick A Sports Team", "Warning!"); 
            }
            else
            {
                txtBoxName.Visible = false;
                txtBxUniform.Visible = true;
                txtBxJerNum.Visible = true;
                txtBxFoot.Visible = true;
                txtBxFldTy.Visible = true;
                txtBxSportGr.Visible = true;
                txtBxTmSz.Visible = true;
                txtBxRefNum.Visible = true;

                btnCreate.Visible = false;
                btnClear.Visible = true;
                btnFin.Visible = true;
                btnReset.Visible = true;

                lblTmNm.Visible = false;
                lblUni.Visible = true;
                lbljers.Visible = true;
                lblftWr.Visible = true;
                lblBxField.Visible = true;
                lblSptGr.Visible = true;
                lblTmSz.Visible = true;
                lblRefNum.Visible = true;
                lblTmShw.Visible = true;
                grpBxTeam.Visible = false;
            }
            
           
            
        }

        private void btnFin_Click(object sender, EventArgs e)
        {
            if (rdBtnSoccer.Checked == true)
            {
                SoccerTeam newSocTeam = new SoccerTeam();
                newSocTeam.TeamName = lblTmShw.Text;
                newSocTeam.UniformType = txtBxUniform.Text;
                newSocTeam.JerseyNum = txtBxJerNum.Text;
                newSocTeam.FootWear = txtBxFoot.Text;
                newSocTeam.FieldType = txtBxFldTy.Text;
                newSocTeam.sportsGear = txtBxSportGr.Text;
                newSocTeam.teamSize = txtBxTmSz.Text;
                newSocTeam.refNum = txtBxRefNum.Text;
                MessageBox.Show(newSocTeam.SoccerDesc(), "Your Team");
            }
            else if (rdBtnTennis.Checked == true)
            {
                TennisTeam newTenTeam = new TennisTeam();
                newTenTeam.TeamName = lblTmShw.Text;
                newTenTeam.UniformType = txtBxUniform.Text;
                newTenTeam.JerseyNum = txtBxJerNum.Text;
                newTenTeam.FootWear = txtBxFoot.Text;
                newTenTeam.FieldType = txtBxFldTy.Text;
                newTenTeam.sportsGear = txtBxSportGr.Text;
                newTenTeam.teamSize = txtBxTmSz.Text;
                newTenTeam.refNum = txtBxRefNum.Text;
                MessageBox.Show(newTenTeam.TennisDesc(), "Your Team");
            }

        }
        private void Reset()
        {
            txtBoxName.Clear();
            txtBxUniform.Clear();
            txtBxJerNum.Clear();
            txtBxFoot.Clear();
            txtBxFldTy.Clear();
            txtBxSportGr.Clear();
            txtBxTmSz.Clear();
            txtBxRefNum.Clear();
            lblTmShw.Text = "";

            txtBoxName.Visible = true;
            txtBxUniform.Visible = false;
            txtBxJerNum.Visible = false;
            txtBxFoot.Visible = false;
            txtBxFldTy.Visible = false;
            txtBxSportGr.Visible = false;
            txtBxTmSz.Visible = false;
            txtBxRefNum.Visible = false;

            btnClear.Visible = false;
            btnFin.Visible = false;
            btnReset.Visible = false;
            btnCreate.Visible = true;

            rdBtnSoccer.Checked = false;
            rdBtnTennis.Checked = false;

            lblUni.Visible = false;
            lbljers.Visible = false;
            lblftWr.Visible = false;
            lblBxField.Visible = false;
            lblSptGr.Visible = false;
            lblTmSz.Visible = false;
            lblRefNum.Visible = false;
            lblTmShw.Visible = false;
            lblTmNm.Visible = true;

            grpBxTeam.Visible = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtBxUniform.Clear();
            txtBxJerNum.Clear();
            txtBxFoot.Clear();
            txtBxFldTy.Clear();
            txtBxSportGr.Clear();
            txtBxTmSz.Clear();
            txtBxRefNum.Clear();

            txtBxUniform.Focus();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Reset();
        }
    }
}
